## Ex 11

`bundle install` - install necessary dependencies

`ruby zadanie_11.rb` - execute script to test connection with Riak DB
