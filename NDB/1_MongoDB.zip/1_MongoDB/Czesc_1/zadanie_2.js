printjson(db.people.findOne({sex:'Female', nationality: 'China'}))
