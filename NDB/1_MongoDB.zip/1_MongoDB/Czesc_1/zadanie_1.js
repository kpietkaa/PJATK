printjson(db.people.findOne())
